/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author jiaenxu
 */
public class AdminDirectory {
    Department department;
    ArrayList<AdminProfile> adlist;
    
    public AdminDirectory(Department department){
        this.department = department;
        adlist = new ArrayList();
    }
    
    public AdminProfile newAdminProfile(Person p){
        AdminProfile ap = new AdminProfile(p);
        adlist.add(ap);
        return ap;
    }
    
    public AdminProfile findAdmin(String id){
        for(AdminProfile ap : adlist){
            if(ap.isMatch(id)) {
                return ap;
            }
        }       
            return null;
    }
}
