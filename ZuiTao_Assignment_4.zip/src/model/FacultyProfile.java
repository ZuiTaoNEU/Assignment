/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author jiaenxu
 */
public class FacultyProfile extends Profile {
    Person person;
    ArrayList <FacultyAssignment> facultyassignments; 
    
    public FacultyProfile(Person p) {
        super(p);
        person = p;
        facultyassignments = new ArrayList();
    }

    public Person getPerson() {
        return person;
    }
    
    
    public  double getProfAverageOverallRating(){
        
        double sum = 0.0;
        //for each facultyassignment extract class rating
        //add them up and divide by the number of teaching assignmnet;
        for(FacultyAssignment fa: facultyassignments){
            
            sum = sum + fa.getRating();
            
        }
        //divide by the total number of faculty assignments
        
        return sum/(facultyassignments.size()*1.0); //this ensure we have double/double
        
    }

    public FacultyAssignment AssignAsTeacher(CourseOffer co){
        
        FacultyAssignment fa = new FacultyAssignment(this, co);
        facultyassignments.add(fa);
        
        return fa;
    }
    
    public FacultyProfile getCourseOffer(String courseid){
        return null; //complete it later
    }
    
    public void addFacultyAssignment(FacultyAssignment assignment) {
        this.facultyassignments.add(assignment);
    }
    
    public ArrayList<FacultyAssignment> getFacultyAssignments() {
        return facultyassignments;
    }
    
    


    
    @Override
    public String getRole() {
        return "Faculty";
    }
}
