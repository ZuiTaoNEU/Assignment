/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author jiaenxu
 */
public class StudentProfile extends Profile {
    Transcript transcript;

    public StudentProfile(Person p) {
        super(p);
        transcript = new Transcript(this);
    }

    public boolean isMatch(String id) {
        return person != null && person.getPersonId().equals(id);
    }

    public Transcript getTranscript() {
        return transcript;
    }

    public CourseLoad getCourseLoadBySemester(String semester) {
        return transcript.getCourseLoadBySemester(semester);
    }

    public CourseLoad getCurrentCourseLoad() {
        return transcript.getCurrentCourseLoad();
    }

    public CourseLoad newCourseLoad(String s) {

        return transcript.newCourseLoad(s);
    }

    public ArrayList<SeatAssignment> getCourseList() {
        return transcript.getCourseList();
    }    

    @Override
    public String getRole() {
        return "Student";
    }
}
