/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author Jiaen
 */
public class CourseCatalog {
    Department department;
    ArrayList<Course> courselist; 
    
    public CourseCatalog(Department d){
        courselist = new ArrayList();
        department = d;
    }
    
    public ArrayList<Course> getCourseList(){
        return courselist;
    }
    
    public Course newCourse( String nm,String n, int cr){
        Course c = new Course(nm, n, cr);
        courselist.add(c); 
        System.out.println("Added new course: " + c.getCourseNumber() + " - " + c.getCourseName());
        return c;
    }
    
    public Course getCourseByNumber(String n){
        
        for(Course c: courselist){
            System.out.println("Checking course: " + c.getCourseNumber());
            if(c.getCourseNumber().equals(n)) {
                System.out.println("Found course: " + c.getCourseNumber());
                return c;
            }
        }
        System.out.println("Course not found: " + n);
        return null;
    }
    
}
