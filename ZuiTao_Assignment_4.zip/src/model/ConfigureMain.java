/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Jiaen
 */
public class ConfigureMain {
    public static Department initialize() {
        Department department = new Department("Information Systems");
        
        PersonDirectory pd = department.getPersonDirectory();
        Person person001 = pd.newPerson("0001","Tory");
        Person person002 = pd.newPerson("1001", "Peter");
        Person person003 = pd.newPerson("2001", "Rick");
        
        AdminDirectory ad = department.getAdmindirectory();
        AdminProfile ap0 = ad.newAdminProfile(person001);
        
        FacultyDirectory fd = department.getFacultyDirectory();
        FacultyProfile fp0 = fd.newFacultyProfile(person002);
        
        StudentDirectory sd = department.getStudentDirectory();
        StudentProfile sp0 = sd.newStudentProfile(person003);
        
        UserAccountDirectory uad = department.getUserAccountDirectory();
        UserAccount ua1 = uad.newUserAccount(ap0, "admin", "0001");
        UserAccount ua2 = uad.newUserAccount(fp0, "faculty", "0001");
        UserAccount ua3 = uad.newUserAccount(sp0, "student", "0001");
        
        
        return department;
    }
}