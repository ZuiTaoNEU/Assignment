/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author Jiaen
 */
public class CourseOffer {

    Course course;
    ArrayList<Seat> seatlist;
    FacultyAssignment facultyassignment;


    public CourseOffer(Course c) {
        course = c;
        seatlist = new ArrayList();
        //facultyassignment = new FacultyAssignment(getFacultyProfile(), this);
    }

    // public FacultyProfile getFacultyProfile() {
    //     return facultyassignment.getFacultyProfile();
    // }

    public FacultyAssignment getFacultyAssignment() {
        return facultyassignment;
    }
    
    
    public void AssignAsTeacher(FacultyProfile fp) {

        facultyassignment = new FacultyAssignment(fp, this);

    }

    public String getCourseNumber() {
        return course.getCourseNumber();
    }

    public void generateSeats(int n) {
        for (int i = 0; i < n; i++) {
            seatlist.add(new Seat(this, i));
        }

    }

    public Seat getEmptySeat() {
        for (Seat s : seatlist) {
            if (!s.isOccupied()) {
                return s;
            }
        }
        return null;
    }

    public int getEmptySeatNumber() {
        int i = 0;
        for (Seat s : seatlist) {
            if (!s.isOccupied()) {
                i += 1;
            }
        }
        return i;
    }

       public int getRegisteredStudentNumber() {
        int i = 0;
        for (Seat s : seatlist) {
            if (s.isOccupied()) {
                i += 1;
            }
        }
        return i;
    }


    public SeatAssignment assignEmptySeat(CourseLoad cl) {
        Seat anEmptySeat = getEmptySeat();
        if (anEmptySeat == null) {
            return null;
        }
        SeatAssignment sa = anEmptySeat.newSeatAssignment(cl); //seat is already linked to course offer
        cl.registerStudent(sa); //coures offer seat is now linked to student
        return sa;
    }

    public int getTotalCourseRevenues() {

        int sum = 0;

        for (Seat s : seatlist) {
            if (s.isOccupied() == true) {
                sum = sum + course.getCoursePrice();
            }

        }
        return sum;
    }

    public Course getSubjectCourse(){
        return course;
    }
    
    public int getCreditHours(){
        return course.getCredits();
    }
    
    public void generatSeats(int n) {

        for (int i = 0; i < n; i++) {

            seatlist.add(new Seat(this, i));

        }

    }
    
    public float calAvgGPA() {
        float sum = 0;
        int count = 0;

        for (Seat s : seatlist) {
            SeatAssignment sa = s.getSeatAssignment();
            if (sa != null) {
                sum += sa.getGPA();
                count++;
            }
        }

        if (count != 0) {
            float avggpa = sum / count;
            float roundedAvgGPA = Math.round(avggpa * 100.0f) / 100.0f;
            return roundedAvgGPA;
        } else {
            return 0.0f;
        }
    }
   
}
