/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.HashMap;

/**
 *
 * @author Jiaen
 */
public class Department {
    String name;
    CourseCatalog coursecatalog;
    PersonDirectory persondirectory;
    StudentDirectory studentdirectory;
    FacultyDirectory facultydirectory;
    AdminDirectory admindirectory;
    HashMap<String, CourseSchedule> mastercoursecatalog;
    
    UserAccountDirectory useraccountdirectory;
    
    
    
    public Department(String n){
        name = n;
        coursecatalog = new CourseCatalog(this);
        studentdirectory = new StudentDirectory(); 
        persondirectory = new PersonDirectory();
        facultydirectory = new FacultyDirectory();
        useraccountdirectory = new UserAccountDirectory();
        admindirectory = new AdminDirectory(this);
        mastercoursecatalog = new HashMap<>(); 
    }

    public AdminDirectory getAdmindirectory() {
        return admindirectory;
    }    
    
    public FacultyDirectory getFacultyDirectory() {
        return facultydirectory;
    }

    public PersonDirectory getPersonDirectory() {
        return persondirectory;
    }    
    
    public StudentDirectory getStudentDirectory() {
        return studentdirectory;
    }
    
    public CourseCatalog getCourseCatalog() {
        return coursecatalog;
    }

    public CourseSchedule newCourseSchedule(String semester) {

        CourseSchedule cs = new CourseSchedule(semester, coursecatalog);
        mastercoursecatalog.put(semester, cs);
        return cs;
    }
    
    public UserAccountDirectory getUserAccountDirectory() {
        return useraccountdirectory;
    }
    
    public HashMap<String, CourseSchedule> getMasterCourseSchedule() {
        return mastercoursecatalog;
    }
    
    
}
